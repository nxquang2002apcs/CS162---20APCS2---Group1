#include "DataStructure.h"
/*
void inputListOfStudent(Class*& cls){
    cout <<"Pls input the number of students: ";    //Khởi tạo số lượng học sinh
    cin >> cls->classSize;     

    Student* pCur = nullptr;
    for(int i = 0; i < cls->classSize; ++i){
        if (cls->HeadStudent == nullptr) {
            cls->HeadStudent = new Student;
            pCur = cls->HeadStudent;
            pCur->pPrev = nullptr;
        }
        else {
            pCur->pNext = new Student;
            pCur->pNext->pPrev = pCur;
            pCur = pCur->pNext;
        }

        cout <<"Student "<<i+1<<": " <<endl;        //Thứ tự nhập
        pCur->no = i + 1;

        cout <<"Enter Student ID: ";       //Nhập MSSV
        getline(cin, pCur->SID);
        fflush(stdin);
        
        cout <<"Enter student's first name: ";       //Nhập firstname 
        getline(cin, pCur->firstName);
        fflush(stdin);

        cout <<"Enter student's last name: ";        //Nhập lastname
        getline(cin, pCur->lastName);
        fflush(stdin);

        cout <<"Gender: ";           //Nhập giới tính
        getline(cin, pCur->gender);
        fflush(stdin);

        cout <<"Enter student's date of Birth: ";    //Nhập ngày sinh
        cout << "Day: ";
        cin >> pCur->DateOfBirth.day;
        cout << "Month: ";
        cin >> pCur->DateOfBirth.month;
        cout << "Year: ";
        cin >> pCur->DateOfBirth.year;
        fflush(stdin);

        cout <<"Enter student's social ID: ";        //Nhập CMND
        getline(cin, pCur->socialID);
        fflush(stdin);

    }

}*/




