﻿#include "DataStructure.h"

bool input_list_of_students_from_CSV(string path, Student*& HeadStudent, int& size) {
    ifstream in;
    string data;
    in.open(path);
    if (!in.is_open()) {
        cout << "Could not open file!";
        _getch();
        return false;
    }
    else {
        Student* CurStudent = HeadStudent;
        getline(in, data);   //Bỏ qua dòng tiêu đề
        while (!in.eof()) {
            if (HeadStudent == nullptr) {
                HeadStudent = new Student;
                CurStudent = HeadStudent;
                CurStudent->pPrev = nullptr;
            }
            else {
                CurStudent->pNext = new Student;
                CurStudent->pNext->pPrev = CurStudent;
                CurStudent = CurStudent->pNext;
            }
            CurStudent->pNext = nullptr;
            size++;                                 //Tăng số lượng sinh viên trong lớp

            getline(in, data, ',');                 
            if (CurStudent->pPrev == nullptr)       //No
                CurStudent->no = 1;
            else CurStudent->no = CurStudent->pPrev->no + 1;
            getline(in, data, ',');                 //SID
            CurStudent->SID = data;
            getline(in, data, ',');                 //First name;
            CurStudent->firstName = data;       
            getline(in, data, ',');                 //Last name
            CurStudent->lastName = data;
            getline(in, data, ',');                 //Gender
            CurStudent->gender = data;
            getline(in, data, '/');
            CurStudent->DateOfBirth.day = stoi(data);           //Ngày sinh
            getline(in, data, '/');         
            CurStudent->DateOfBirth.month = stoi(data);         //Tháng sinh
            getline(in, data, ',');
            CurStudent->DateOfBirth.year = stoi(data);          //Năm sinh
            getline(in, data);                      //Social ID
            CurStudent->socialID = data;

            CurStudent->FirstYear = CurrentYear->startYear;     //Năm học đầu tiên là năm được tạo
            CurStudent->gpa = 0;                                //Mới thêm nên chưa có GPA
            CurStudent->Head_of_enrolled_course = nullptr;      //SV mới thêm chưa thể đăng ký môn học
        }
    }
    in.close();
    return true;
};

void input_list_of_course_from_CSV(string path, Semester curSemester) {
    ifstream in;
    in.open(path);
    if (!in.is_open()) {
        cout << "Cannot open file!" << endl;
        return;
    }
    else {

    }
}