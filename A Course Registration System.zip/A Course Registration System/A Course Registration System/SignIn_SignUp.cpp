#include "DataStructure.h"

// Function to take valid username from user and their password. Then take password from username file to compare
bool Read_Name_Pass(ifstream& in, string& username, string& password) {
	string userfile, passfile;
	string path;

	path = "Data2\\Username_password\\" + username + ".txt";
	in.open(path);
	if (!in.is_open()) {
		gotoXY(80, 20);
		cout << "Invadid Username. Enter again!";
		_getch();
		return false;
	}
	else {
		getline(in, userfile);
		getline(in, passfile);

		if (password == passfile) {
			in.close();
			return true;
		}
		else {
			int i = 19;
			gotoXY(76, 19);
			cout << "Incorrect password. Please try again!";
			_getch();
			in.close();
			return false;
		}
	}

}

// Function to log in
// Function will run until logging in sucessfully
bool login(ifstream& in, int& role, string& studentID)
{
	string username, password;
	int wrong_pass = 0;
	while (true) {
		username = password = "";
		system("cls");
		DrawRectangleDouble(67, 6, 48, 2);
		gotoXY(70, 7);
		TextColor(9);
		cout << "Welcome to HCMUS course registration system!" << endl;
		TextColor(15);
		DrawRectangleDouble(77, 11, 30, 6);
		gotoXY(89, 12);
		TextColor(14);
		cout << "SIGN IN";
		TextColor(15);
		gotoXY(80, 14);
		cout << "Username: ";
		getline(cin, username);
		gotoXY(80, 16);
		cout << "Password: ";
		getline(cin, password);


		if (Read_Name_Pass(in, username, password)) {
			if ((int)username[0] >= 48 && (int)username[0] <= 57) {
				role = 1;
				studentID = username;
			}
			else
				role = 2;
			gotoXY(83, 20);
			TextColor(14);
			cout << "LOG IN SUCCESSFULLY!" << endl;
			TextColor(15);
			cout << endl;
			gotoXY(80, 22);
			cout << "Please waiting! Loading";
			Nocursortype();
			for (int i = 0; i <= 100; ++i) {
				gotoXY(104, 22);
				cout << i << "%";
				Sleep(30);
			}
			UnNocursortype();
			return true;
		}
		else {
			wrong_pass++;
			if (wrong_pass > 5) {
				gotoXY(66, 19);
				cout << "You are failed to login for five times! Cannot try anymore!";
				_getch();
				return false;
			}
		}
	}
	
}

// Function to change password
void changePassword(ofstream& out, string username)
{
	string password, newpassword = "1", newpassword2 = "0";

	//Read_Name_Pass(in, username, password);
	cin.get();
	while (newpassword != newpassword2)
	{
		cout << "New password: ";
		getline(cin, newpassword);
		cout << "Confirm password: ";
		getline(cin, newpassword2);

		if (newpassword != newpassword2)
			cout << "Don't match. Enter again!" << endl;
	}

	string path = "Data2\\Username_password\\" + username + ".txt";
	out.open(path);
	if (!out.is_open())
	{
		cout << "Can not open file!" << endl;
		cout << "Changing password failed!";
		_getch();
		return;
	}

	out << username << endl;
	out << newpassword << endl;

	out.close();

	cout << "CHANGE PASSWORD SUCCESSFULLY!";
	_getch();
}

//Function to log out 
void logOut() {
	system("cls");
	
	DrawRectangleDouble(77, 18, 33, 6);
	gotoXY(91, 19);
	TextColor(14);
	cout << "LOG OUT";
	TextColor(15);
	gotoXY(88, 21);
	cout << "Successfully!";
	gotoXY(80, 23);
	cout << "Please waiting! Loading ";
	Nocursortype();
	for (int i = 0; i <= 100; ++i) {
		gotoXY(104, 23);
		cout << i << "%";
		Sleep(30);
	}
	UnNocursortype();

	return;
}

//Function to exit program
void ExitProgram() {
	system("cls");
	
	DrawRectangleDouble(75, 18, 37, 6);
	gotoXY(80, 19);
	TextColor(14);
	cout << "THANKS FOR USING OUR PROGRAM!";
	TextColor(15);
	gotoXY(78, 21);
	cout << "Please waiting! Program is saving";
	gotoXY(88, 23);
	cout << "Loading";
	Nocursortype();
	for (int i = 0; i <= 100; ++i) {
		gotoXY(96, 23);
		cout << i << "%";
		Sleep(30);
	}
	UnNocursortype();
	cout << endl << endl;
	writeAll(HeadYear);
	delete_everything();
	exit(0);

}