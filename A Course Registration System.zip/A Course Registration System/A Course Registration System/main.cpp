﻿#include "DataStructure.h"

int main() {
	ifstream in;
	int role = 1;
	string studentID;
	bool logSuccess = false;
	readAll();									//Đọc dữ liệu của hệ thống từ cơ sở dữ liệu vào chương trìn

	while (true)   {
		role = 2;
		if (login(in, role, studentID)) {
			if (role == 1)						//Nếu role = 1, nghĩa là người dùng là student
				StudentInterface(studentID);	
			else StaffInterface();				//role = 2, người dùng là staff
		}
		else break;  
	}

	writeAll(HeadYear);							//Ghi dữ liệu từ chương trình ra cơ sở dữ liệu
	delete_everything();						//Vì sử dụng linked list nên phải xóa tất cả con trỏ trước khi đóng chương trình

	in.close();
	
	
	return 0;
}

