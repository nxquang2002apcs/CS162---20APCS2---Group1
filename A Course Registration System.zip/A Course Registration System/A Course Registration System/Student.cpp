﻿#include "DataStructure.h"


void view_my_profile(Student*& student);
// Đi tới danh sách những môn đã đăng ký
void go_to_my_enrolled_course(Student*& student);
//Hàm xóa
void deleteEnrolledCourse(Student*& student, string courseID);



// Hàm xem scoreboard của student
void view_scoreboard_of_student(Student* student)
{
	system("cls");
	TextColor(14);
	cout << CurrentYear->startYear << "-" << CurrentYear->endYear << " >> Class " << student->className << " >> " << student->firstName + " " + student->lastName << endl;
	TextColor(15);
	cout << "--------------------------------------------------" << endl;

	if (student->Head_of_enrolled_course == nullptr) {
		cout << "No enrolled course!" << endl;
		return;
	}

	cout << char(218);
	for (int i = 0; i < 157; ++i)
		cout << char(196);
	cout << char(191) << endl;

	cout << char(179);
	cout << "   " << setw(12) << left << "Course ID";
	cout << setw(35) << "Course Name";
	cout << setw(20) << left << "Lecturer Name";
	cout << "Number of credits   ";
	cout << setw(15) << "Session 1  ";
	cout << setw(12) << "Session 2";
	cout << setw(9) << left << "Midterm";
	cout << setw(7) << left << "Final";
	cout << setw(12) << left << "Other mark";
	cout << "Course's GPA" << char(179) << endl;

	cout << char(195);
	for (int i = 0; i < 157; ++i)
		cout << char(196);
	cout << char(180) << endl;

	CourseForEachStudent* Head_course = student->Head_of_enrolled_course;

	while (Head_course)
	{
		cout << char(179);
		cout << Head_course->numberCourse << ". ";
		cout << setw(12) << left << Head_course->detail.courseID;
		cout << setw(35) << left << Head_course->detail.courseName;
		cout << setw(17) << left << Head_course->detail.teacherName;
		cout << setw(13) << right << Head_course->detail.credits;
		cout << setw(15) << right << Head_course->detail.session1;
		cout << setw(15) << right << Head_course->detail.session2;
		cout << setw(9) << right << " ";  print(Head_course->midterm);
		cout << setw(4) << right << " "; print(Head_course->final);
		cout << setw(6) << right << " "; print(Head_course->otherMark);
		cout << setw(9) << right << " "; print(Head_course->courseGPA);
		cout << setw(3) << right << " " << char(179);

		Head_course = Head_course->pNext;

		cout << endl;
	}

	cout << char(192);
	for (int i = 0; i < 157; ++i)
		cout << char(196);
	cout << char(217) << endl;

	if (Available_all_scoreboard == true) {
		cout << "--------------------------------------------------" << endl;
		TextColor(14);
		cout << "Overall GPA: " << student->gpa << endl;
		TextColor(15);
	}

	int user;
	cout << endl;
	cout << "0. Return" << endl;
	cout << "User: ";
	cin >> user;
	while (user != 0) {
		cout << "Invalid input! Please try again!" << endl;
		cout << "User: ";
		cin >> user;
	}

	return;
}
//Tìm đến sinh viên có ID trùng với mật khẩu đăng nhập
Student* findStudent(string studentID) {
	Class* tempClass = CurrentYear->HeadClass;
	Student* tempStudent = nullptr;
	while (tempClass != nullptr) {
		tempStudent = tempClass->HeadStudent;
		while (tempStudent != nullptr && tempStudent->SID != studentID)
			tempStudent = tempStudent->pNext;

		if (tempStudent == nullptr) {
			tempClass = tempClass->pNext;
		}
		else return tempStudent;
	}
	return nullptr;
}
//Hàm xem profile
void view_my_profile(Student*& student) {
	int choice = 0;
	while (true) {
		system("cls");

		TextColor(14);
		cout << student->className << " >> " << student->SID << " " << student->firstName << " " << student->lastName << endl;
		TextColor(15);
		cout << "---------------------------------------" << endl;
		cout << "Full name: " << student->firstName << " " << student->lastName << endl;
		cout << "SID: " << student->SID << endl;
		cout << "Class: " << student->className << endl;
		cout << "School Year: " << CurrentYear->startYear << "-" << CurrentYear->endYear << endl;
		cout << "Gender: " << student->gender << endl;
		cout << "Date of Birth: " << student->DateOfBirth.day << "/" << student->DateOfBirth.month << "/" << student->DateOfBirth.year << endl;
		cout << "Social ID: " << student->socialID << endl;
		cout << "---------------------------------------" << endl;

		cout << endl;
		cout << "0. Return menu" << endl;
		cout << "User: ";
		cin >> choice;
		while (choice != 0) {
			cout << "Invalid input! Please try again!" << endl;
			cout << "User: ";
			cin >> choice;
		}
		return;
	}
}
//Hàm xem ds các môn sinh viên đã đăng ký
void go_to_my_enrolled_course(Student*& student) {
	int choice = 0;
	while (true) {
		system("cls");
		TextColor(14);
		cout << student->className << " >> " << student->SID << " >> " << "My enrolled courses" << endl;
		TextColor(15);
		cout << "------------------------------------------" << endl;
		cout << "List of courses: " << endl;
		view_list_of_enrolled_course(student);
		cout << endl;
		
		if (Available_register == true) {
			int x = whereX();
			int y = whereY();
			DrawRectangleDouble(x, y, 90, 3);
			gotoXY(x + 2, y + 1);
			cout << "*** NOTIFICATION ***" << endl;
			gotoXY(x + 2, y + 2);
			cout << "Course registration is active now! You can enroll new courses by choosing OPTION 1." << endl;
			cout << endl << endl;
		}

		cout << "0. Return menu" << endl;
		if (Available_register) {
			cout << "1. Enroll new courses" << endl;
			cout << "2. Remove courses" << endl;
		}
		cout << "User: ";
		cin >> choice;

		switch (choice) {
		case 0:
			return;
		case 1:
			if (Available_register) {
				system("cls");
				enroll_a_course(student, CurrentSemester->HeadCourse);
			}
			break;
		case 2:
			if (Available_register) {
				int c;
				//Check có đúng là muốn xóa khóa học không
				cout << "You want to remove a course? (YES/NO): " << endl;
				cout << "  1. YES			2. NO" << endl;;
				cout << "User: ";
				cin >> c;
				while (c != 1 && c != 2) {
					cout << "Invalid input!" << endl;
					cout << "User: ";
					cin >> c;
				}
				if (c == 1) {
					string courseID;
					cout << "Enter course's ID you want to remove: ";
					cin.ignore();
					getline(cin, courseID);
					deleteEnrolledCourse(student, courseID);
				}
				else {
					cout << "CANCLE REMOVE!";
					_getch();
					break;
				}
			}
			break;
		}
	}
}

//hàm check có bị trùng lịch học không
bool check(Student* student, string ses1, string ses2) {

	if (student->Head_of_enrolled_course == nullptr)
		return true;

	CourseForEachStudent* tmp = student->Head_of_enrolled_course;

	while (tmp) {
		//so sánh string
		if (tmp->detail.session1.compare(ses1) == 0 || tmp->detail.session2.compare(ses2) == 0)
			return false;
		tmp = tmp->pNext;
	}
	return true;
}
//Sinh viên đăng ký môn học
void enroll_a_course(Student*& student, CourseDetail*& enrolledCourse) {

	int numberDefaultCourse = 5;
	//node chạy course system
	CourseDetail* tmpCourse = enrolledCourse;

	//Node chạy danh sách sinh viên khóa học
	Student_CourseScores* tmpCourseList = enrolledCourse->HeadStudent;

	//Node chạy của course mỗi sinh viên
	CourseForEachStudent* tmpEach = student->Head_of_enrolled_course;

	//Hiển thị danh sách khóa học cho sinh viên đăng kí
	view_list_of_courses(CurrentSemester);

	int i = 0;
	do {
		int c;
		//Check có muốn đăng kí tiếp khóa học không
		cout << "You want to enroll a course? (YES/NO): " << endl;
		cout << "  1. YES			2. NO" << endl;;
		cout << "User: ";
		cin >> c;
		while (c != 1 && c != 2) {
			cout << "Invalid input!" << endl;
			cout << "User: ";
			cin >> c;
		}
		if (c == 2)
			break;
		else if (c == 1) {
			cout << "Please enter Course ID to enroll: ";
			string id;
			cin.ignore();
			getline(cin, id);

			tmpCourse = enrolledCourse;

			while (tmpCourse) {

				//check có trùng ID không
				if (tmpCourse->courseID.compare(id) == 0) {

					//check course còn slot không
					if (tmpCourse->enrolledStudent < tmpCourse->numberStudent) {

						//check có bị trùng ca học không
						if (check(student, tmpCourse->session1, tmpCourse->session2)) {
							while (tmpEach->pNext != nullptr)
								tmpEach = tmpEach->pNext;

							if (student->Head_of_enrolled_course == nullptr) {

								student->Head_of_enrolled_course = new CourseForEachStudent;
								tmpEach = student->Head_of_enrolled_course;
								tmpEach->numberCourse = 1;
								tmpEach->pPrev = nullptr;

							}
							else {
								tmpEach->pNext = new CourseForEachStudent;
								tmpEach->pNext->pPrev = tmpEach;
								tmpEach = tmpEach->pNext;
								tmpEach->numberCourse = tmpEach->pPrev->numberCourse + 1;
								student->numberOfCourse++;
							}

							//thêm khóa học cho sinh viên
							tmpEach->detail.courseID = tmpCourse->courseID;
							tmpEach->detail.courseName = tmpCourse->courseName;
							tmpEach->detail.teacherName = tmpCourse->teacherName;
							tmpEach->detail.credits = tmpCourse->credits;
							tmpEach->detail.session1 = tmpCourse->session1;
							tmpEach->detail.session2 = tmpCourse->session2;

							/*tmpEach->final = 0;
							tmpEach->midterm = 0;
							tmpEach->otherMark = 0;
							tmpEach->total = 0;
							*/

							//tăng số lượng sinh viên đã enrol thành công khóa học
							tmpCourse->enrolledStudent++;
							tmpCourseList = tmpCourse->HeadStudent;
							//thêm danh sách sinh viên tham gia khóa học
							if (tmpCourse->HeadStudent == nullptr) {
								tmpCourse->HeadStudent = new Student_CourseScores;
								tmpCourseList = tmpCourse->HeadStudent;
								tmpCourseList->no = 1;
								tmpCourseList->pPrev = nullptr;
							}
							else {
								int no = tmpCourseList->no;
								while (tmpCourseList->pNext != nullptr) {
									tmpCourseList = tmpCourseList->pNext;
								}
								tmpCourseList->pNext = new Student_CourseScores;
								tmpCourseList->pNext->pPrev = tmpCourseList;
								tmpCourseList->no = no + 1;
								tmpCourseList = tmpCourseList->pNext;
							}

							tmpCourseList->firstName = student->firstName;
							tmpCourseList->lastName = student->lastName;
							tmpCourseList->className = student->className;
							tmpCourseList->gender = student->gender;
							tmpCourseList->SID = student->SID;
							tmpCourseList->midterm = 0;
							tmpCourseList->final = 0;
							tmpCourseList->otherMark = 0;
							tmpCourseList->courseGPA = 0;
							tmpCourseList->pNext = nullptr;
							/*
							//Node chay lien ket diem cua student_courseScore voi CourseForEach
							CourseForEachStudent* tmp = tmpCourseList->point_to_an_enrolled_course_of_a_student_in_a_class;
							while (tmp->detail.courseID != id)
								tmp = tmp->pNext;

							tmp->midterm = tmpCourseList->midterm;
							tmp->final = tmpCourseList->final;
							tmp->otherMark = tmpCourseList->otherMark;
							tmp->courseGPA = tmpCourseList->courseGPA;
							*/

							tmpCourseList->point_to_an_enrolled_course_of_a_student_in_a_class = tmpEach;

							tmpEach->pNext = nullptr;

							cout << "Enroll Successfully." << endl;
							cout << "You have enrolled in " << tmpEach->detail.courseName << endl;
							i++;
							break;
						}
						else {
							cout << "Session conflicted! Try Again!" << endl;
							break;
						}
					}
					else {
						cout << "The course is full. Try other course!" << endl;
						break;
					}
				}
				tmpCourse = tmpCourse->pNext;
			}
		}

		//Nếu nhập sai thì hỏi lại
		else
			continue;
	} while (i < numberDefaultCourse);

}
//Hàm xóa môn học đã đăng ký
void deleteEnrolledCourse(Student*& student, string courseID)
{
	CourseDetail* pCurCourse = CurrentSemester->HeadCourse;
	while (pCurCourse != nullptr && pCurCourse->courseID != courseID)	// Tìm đến Course cần delete
		pCurCourse = pCurCourse->pNext;

	if (pCurCourse == nullptr)	// Nếu không tìm thấy
	{
		cout << "Course not found. Cannot delete!" << endl;
		return;
	}
	else	// Nếu tìm thấy
	{
		pCurCourse->enrolledStudent--;
		Student_CourseScores* pCurStudent = pCurCourse->HeadStudent;
		while (pCurStudent->SID != student->SID && pCurStudent != nullptr)	// Tìm đến Student_CourseScores của sinh viên trong Course vừa tìm được
			pCurStudent = pCurStudent->pNext;

		if (pCurStudent == nullptr)	// Nếu không tìm thấy, có thể sinh viên chưa đăng ký môn này
		{
			cout << "The student may not has enrolled this course. Delete failed!" << endl;
			return;
		}
		else	// Nếu tìm thấy, bắt đầu delete
		{
			CourseForEachStudent* deleteEnrolled = pCurStudent->point_to_an_enrolled_course_of_a_student_in_a_class;	// Delete CourseForEachStudent của sinh viên
			if (deleteEnrolled->pPrev == nullptr)	// Trường hợp delete Head_of_enrolled_course
			{
				student->Head_of_enrolled_course = deleteEnrolled->pNext;	// Chuyển Head_of_enrolled_course sang node kế tiếp

				if (student->Head_of_enrolled_course != nullptr)	// Nếu node kế tiếp tồn tại
					student->Head_of_enrolled_course->pPrev = nullptr;	// Set pPrev của node đó về nullptr

				delete deleteEnrolled;
			}
			else	// Trường hợp đứng giữa hoặc cuối
			{
				deleteEnrolled->pPrev->pNext = deleteEnrolled->pNext;	// Nối lại các node

				if (deleteEnrolled->pNext != nullptr)	// Nếu không phải là node cuối cùng
					deleteEnrolled->pNext->pPrev = deleteEnrolled->pPrev;

				delete deleteEnrolled;
			}

			// Delete Student_CourseScores

			if (pCurStudent->pPrev == nullptr)	// Trường hợp delete HeadStudent
			{
				pCurCourse->HeadStudent = pCurStudent->pNext;	// Chuyển HeadStudent sang node kế tiếp

				if (pCurCourse->HeadStudent != nullptr)	// Nếu node kế tiếp tồn tại
					pCurCourse->HeadStudent->pPrev = nullptr;	// Set pPrev của node đó về nullpter

				delete pCurStudent;
				cout << "DELETE SUCCESSFULLY!";
				_getch();
				return;
			}
			else	// Trường hợp đứng giữa hoặc đứng cuối
			{
				pCurStudent->pPrev->pNext = pCurStudent->pNext;	// Nối lại các node

				if (pCurStudent->pNext != nullptr)	// Nếu không phải là node cuối cùng
					pCurStudent->pNext->pPrev = pCurStudent->pPrev;

				delete pCurStudent;
				cout << "DELETE SUCCESSFULLY!";
				_getch();
				return;
			}
		}
	}
}

//Giao diện làm việc của Student
void StudentInterface(string studentID) {

	Student* user = findStudent(studentID);            //Người dùng là sv có SID trùng với mật khẩu đăng nhập
	if (user == nullptr) {
		cout << "Your profile is not available in database!" << endl;
		return;
	}

	int choice = 0;
	while (true) {
		system("cls");
		DrawRectangleDouble(66, 1, 54, 8);
		TextColor(9);
		gotoXY(70, 2);
		cout << "xx    xx   xxxxxx  xxxx   xxxx  xx    xx  xxxxxx" << endl;
		gotoXY(70, 3);
		cout << "xx    xx  xx       xx xx xx xx  xx    xx  xx    " << endl;
		gotoXY(70, 4);
		cout << "xxxxxxxx  xx       xx  xxx  xx  xx    xx  xxxxxx" << endl;
		gotoXY(70, 5);
		cout << "xx    xx  xx       xx       xx  xx    xx      xx" << endl;
		gotoXY(70, 6);
		cout << "xx    xx   xxxxxx  xx       xx   xxxxxx   xxxxxx" << endl;
		gotoXY(76, 8);
		TextColor(14);
		cout << "*** COURSE REGISTRATION SYSTEM ***" << endl;
		TextColor(15);

		gotoXY(80, 12);
		cout << "-------------------------------" << endl;
		gotoXY(80, 13);
		TextColor(14);
		cout << " " << user->className << " >> " << user->firstName << " " << user->lastName << endl;
		TextColor(15);
		gotoXY(80, 14);
		cout << "-------------------------------" << endl;
		int j = 15;
		gotoXY(54, j++);
		if (Available_register == true) {
			int x = whereX();
			int y = whereY();
			DrawRectangleDouble(x, y, 90, 3);
			gotoXY(x + 2, y + 1);
			TextColor(14);
			cout << "*** NOTIFICATION ***" << endl;
			TextColor(15);
			gotoXY(x + 2, y + 2);
			cout << "Course registration is active now! You can enroll new courses by choosing OPTION 3." << endl;
			cout << endl << endl;
			j += 4;
		}
		else if (Available_all_scoreboard == true) {
			int x = whereX();
			int y = whereY();
			DrawRectangleDouble(x, y, 80, 3);
			gotoXY(x + 2, y + 1);
			TextColor(14);
			cout << "*** NOTIFICATION ***" << endl;
			TextColor(15);
			gotoXY(x + 2, y + 2);
			cout << "Course's scoreboard is available now. To view scoreboard, choose OPTION 3." << endl;
			cout << endl << endl;
			j += 4;
		}

		gotoXY(83, j++);
		cout << "1. View my profile" << endl;
		gotoXY(83, j++);
		cout << "2. My list of courses" << endl;
		int i = j++;
		if (Available_register == true) {
			gotoXY(83, i++);
			cout << "3. Enroll new courses" << endl;
		}
		else if (Available_all_scoreboard == true) {
			gotoXY(83, i++);
			cout << "3. View my scoreboard" << endl;
		}
		gotoXY(83, i++);
		cout << "4. Change password" << endl;
		gotoXY(83, i++);
		cout << "5. Log out" << endl;
		gotoXY(83, i++);
		cout << "6. Exit program" << endl;
		gotoXY(83, i++);
		cout << "User: ";
		cin >> choice;

		switch (choice) {
		case 1:
			view_my_profile(user);
			break;
		case 2:
			go_to_my_enrolled_course(user);
			break;
		case 3:
			if (Available_register == true) {
				system("cls");
				enroll_a_course(user, CurrentSemester->HeadCourse);
			}
			else if (Available_all_scoreboard == true) {
				view_scoreboard_of_student(user);
			}
			break;
		case 4:
			int c;
			//Hỏi xác nhận là muốn đổi mk hay không.
			cout << "You want to change password? (YES/NO): " << endl;
			cout << "  1. YES			2. NO" << endl;;
			cout << "User: ";
			cin >> c;
			while (c != 1 && c != 2) {
				cout << "Invalid input!" << endl;
				cout << "User: ";
				cin >> c;
			}
			if (c == 1) {
				ofstream out;
				changePassword(out, user->SID);
			}
			break;
		case 5:
			cin.get();
			logOut();
			return;
		case 6:
			ExitProgram();
			delete_everything();
			exit(0);
		default:
			cout << "Invalid input! Please try again!";
			_getch();
			break;
		}
	}
}