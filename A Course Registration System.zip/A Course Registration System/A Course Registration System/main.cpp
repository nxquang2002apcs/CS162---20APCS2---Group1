﻿#include "DataStructure.h"


int main() {
	ifstream in;
	int role = 1;
	string studentID;
	bool logSuccess = false;
	readAll();
	//delete_everything();
	while (true)   {
		role = 2;
		if (login(in, role, studentID)) {
			if (role == 1)
				StudentInterface(studentID);
			else StaffInterface();
		}
		else break;  
	}

	writeAll(HeadYear);
	delete_everything();

	in.close();
	
	
	return 0;
}

